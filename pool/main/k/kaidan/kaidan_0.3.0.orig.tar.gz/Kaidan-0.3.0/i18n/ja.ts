<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja">
<context>
    <name>AboutPage</name>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A simple, user-friendly Jabber/XMPP client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>License:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sourcecode on Github</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChatPage</name>
    <message>
        <source>Compose message</source>
        <translation>メッセージを書く</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>送る</translation>
    </message>
</context>
<context>
    <name>GlobalDrawer</name>
    <message>
        <source>Logout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new contact</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LoginPage</name>
    <message>
        <source>Your Jabber-ID:</source>
        <translation>君のJabber-ID：</translation>
    </message>
    <message>
        <source>user@example.org</source>
        <translation>user＠example.jp</translation>
    </message>
    <message>
        <source>Your Password:</source>
        <translation>君の合言葉：</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="vanished">合言葉</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect</source>
        <translation>接続</translation>
    </message>
    <message>
        <source>Connecting...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log in to your Jabber Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your diaspora*-ID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>user@diaspora.pod</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RosterAddContactSheet</name>
    <message>
        <source>Nickname:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jabber-ID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>user@example.org</source>
        <translation type="unfinished">user＠example.jp</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new contact</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RosterPage</name>
    <message>
        <source>Contacts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RosterRemoveContactSheet</name>
    <message>
        <source>Do you really want to delete the contact &quot;%1&quot; from your roster?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
</context>
</TS>
